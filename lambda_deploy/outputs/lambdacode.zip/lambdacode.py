def hello(event, context):
    print("demo of AWS lambda using terraform")